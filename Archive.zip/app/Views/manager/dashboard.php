<?= $this->extend('manager/template'); ?>

<?= $this->section('content'); ?>
<div class="row">
    <div class="col-lg-12 mb-lg-0 mb-4">
        <div class="card">
            <div class="card-header p-3">
                <div class="d-flex align-items-center">
                    <p class="mb-0">Selamat Datang</p>
                </div>
            </div>
            <p class="p-3">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iste dolore dolor, aut ex vitae mollitia aperiam? Voluptatem amet facilis odio eligendi quasi a facere laboriosam ut optio magni! Qui vel error modi excepturi atque sapiente fugiat nam dolores voluptatem labore mollitia necessitatibus corporis, eaque dignissimos aspernatur ipsam sint fugit illum voluptate unde velit beatae dolorum cumque numquam! Recusandae reiciendis commodi eligendi saepe, vero temporibus repellendus, rerum eum soluta iusto dignissimos repellat id corrupti nostrum perspiciatis quo culpa magni magnam doloribus. Quasi ipsam voluptas, placeat neque repellendus aspernatur voluptate rem necessitatibus temporibus dolore voluptatibus beatae consequatur qui ratione? Veritatis, dolores consequuntur.
            </p>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>